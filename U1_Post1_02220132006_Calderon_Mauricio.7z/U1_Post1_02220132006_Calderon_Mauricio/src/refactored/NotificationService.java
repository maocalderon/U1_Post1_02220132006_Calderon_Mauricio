package refactored;

public interface NotificationService {
    void notify(String recipient, String message);
}